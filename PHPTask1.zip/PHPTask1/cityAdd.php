<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo isset($id) ? 'Update City' : 'Add City'; ?></title>
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .container {
            max-width: 600px;
            margin-top: 50px;
        }

        .form-container {
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.1);
            background-color: #ffffff;
        }

        .form-header {
            margin-bottom: 20px;
        }
    </style>
</head>

<body>

    <?php
    session_start();
    include("conn.php");

    $name = '';
    $id = '';
    $country_id = '';
    $state_id = '';
    $error = '';
    $states = []; 

    if (isset($_GET['id'])) {
        $id = $_GET['id'];
        $stmt = $con->prepare("SELECT city.*, country.name AS country_name, states.s_name AS state_name 
                                FROM city 
                                JOIN states ON city.state_id = states.id 
                                JOIN country ON states.country_id = country.id 
                                WHERE city.id = ?");
        $stmt->bind_param('i', $id);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($row = $result->fetch_assoc()) {
            $state_id = $row['state_id'];
            $name = $row['c_name'];
            $country_id = $row['country_id'];
        }
    }

    // Fetch states 

    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        $country_id = $_POST['country_id'];

        if (!empty($country_id)) {
            $stmt = $con->prepare("SELECT id, s_name FROM states WHERE country_id = ?");
            $stmt->bind_param('i', $country_id);
            $stmt->execute();
            $result = $stmt->get_result();

            while ($row = $result->fetch_assoc()) {
                $states[] = $row; 
            }
        }
    }

    if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['submit'])) {
        $name = trim($_POST['name']);
        $state_id = $_POST['state_id'];

        // Input validation
        if (empty($name)) {
            $error = "Please enter the city name.";
        } elseif (!preg_match('/^[a-zA-Z\s]+$/', $name)) {
            $error = "Please enter a valid city name.";
        } elseif (empty($country_id)) {
            $error = "Please select a country.";
        } elseif (empty($state_id)) {
            $error = "Please select a state.";
        }

        if (empty($error)) {
            if ($id) {
                $stmt = $con->prepare("UPDATE city SET c_name = ?, state_id = ? WHERE id = ?");
                $stmt->bind_param('sii', $name, $state_id, $id);
                if ($stmt->execute()) {
                    header("Location: city.php?status=update");
                    exit();
                } else {
                    $error = "Error updating city.";
                }
            } else {
                $stmt = $con->prepare("SELECT * FROM city WHERE c_name = ? AND state_id = ?");
                $stmt->bind_param('si', $name, $state_id);
                $stmt->execute();
                $result = $stmt->get_result();

                if ($result->num_rows > 0) {
                    $error = "This city already exists in the selected state.";
                } else {
                    $stmt = $con->prepare("INSERT INTO city(c_name, state_id) VALUES (?, ?)");
                    $stmt->bind_param('si', $name, $state_id);
                    if ($stmt->execute()) {
                        header('Location: city.php?status=success');
                        exit();
                    } else {
                        $error = "Error inserting city.";
                    }
                }
            }
            $stmt->close();
        }
    }

    $con->close();
    ?>

    <div class="container">
        <div class="form-container">
            <h2 class="form-header text-center"><?php echo isset($id) ? 'Update City' : 'Add City'; ?></h2>
            <?php if ($error): ?>
                <div class='alert alert-danger' role='alert'><?php echo ($error); ?></div>
            <?php endif; ?>

            <form method="POST">
                <div class="form-group">
                    <label for="country">Select Country</label>
                    <select id="country_id" name="country_id" class="form-control" onchange="this.form.submit();">
                    <option value="">Select Country</option>
                        <?php

                        // Fetch countries for the dropdown
                        
                        include('conn.php');
                        $stmt = $con->prepare("SELECT id, name FROM country");
                        $stmt->execute();
                        $result = $stmt->get_result();

                        while ($row = $result->fetch_assoc()) {
                            $selected = ($row['id'] == $country_id) ? 'selected' : '';
                            echo "<option value=\"{$row['id']}\" $selected>{$row['name']}</option>";
                        }
                        ?>
                    </select>
                </div>
                <div class="form-group">
                    <label for="state">Select State</label>
                    <select id="state_id" name="state_id" class="form-control">
                        <option value="">Select State</option>
                        <?php
                        foreach ($states as $state) {
                            $selected = ($state['id'] == $state_id) ? 'selected' : '';
                            echo "<option value=\"{$state['id']}\" $selected>{$state['s_name']}</option>";
                        }
                        ?>
                    </select>
                </div>
                <div class="form-group">
                    <label for="name">Enter City Name</label>
                    <input type="text" class="form-control" name="name" value="<?php echo ($name); ?>" placeholder="Enter city name">
                </div>
                <input type="submit" name="submit" class="btn btn-primary" value="Submit">
                <!-- <butto n type="submit" name="submit" class="btn btn-primary btn-block mb-3">Submit</button> -->
                <p>Don't want to add a city? <a href="city.php">Go Back</a></p>
            </form>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>

</html>
