<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

    <style>
        body {
            background-color: #f8f9fa;
        }

        #sidebar {
            min-height: 100vh;
        }

        .table-hover tbody tr:hover {
            background-color: #e9ecef;
        }

        .btn-primary {
            background-color: #007bff;
            border-color: #007bff;
        }

        .row1 h2 {
            margin-bottom: 25px;
        }

        .fas {
            margin-right: 20px;
        }

        .nav-link {
            color: rgb(41, 41, 182);
            margin-bottom: 10px;
        }
    </style>
</head>

<body>
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-2 bg-light text-dark p-4 " id="sidebar">
                <h2 class="ps-4 pb-3">Admin</h2>
                <ul class="nav flex-column">
                    <li class="nav-item">
                        <a class="nav-link active" href="index.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="country.php"><i class="fas fa-flag"></i> Country</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="state.php"><i class="fas fa-map-marker-alt"></i> State</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="city.php"><i class="fas fa-building"></i> City</a>
                    </li>

                </ul>
            </div>
            <div class="col-md-10 p-4" id="main-content">
                <div class="row mb-4">
                    <div class="col">
                        <h3><i class="fas fa-globe"></i> States Listing</h3>
                    </div>

                </div>

                <form method="Get" class="row mb-3 mt-0">


                    <div class="row">

                        <div class="col col-lg-3 flex-end">
                        <input class="form-control" type="search" name="search" value="<?php echo isset($_GET['search']) ? htmlspecialchars($_GET['search']) : ''; ?>" placeholder="Search" aria-label="Search">
                        
                        </div>
                        <div class="col-auto">
                            <button type="submit" class="btn btn-success mb-3">Search</button>

                        </div>
                        <div class="col col-lg-5"></div>
                        <div class="col">
                            <a href="stateAdd.php" class="btn btn-primary mb-3"><i class="fas fa-plus me-2"></i> Add
                                State</a>
                        </div>
                    </div>
                </form>

                <table class="table table-striped table-hover card-body">
                    <thead>
                        <tr>
                            <th>
                                State ID
                                <div class="dropdown d-inline">
                                    <a class="btn dropdown-toggle" style="box-shadow:none;" href="#" role="button"
                                        id="dropdownMenuLink" data-bs-toggle="dropdown" aria-expanded="false">
                                        <i class="fa fa-sort"></i>
                                    </a>

                                    <ul class="dropdown-menu" aria-labelledby="dropdownMenuLink">
                                        <li><a class="dropdown-item" href="?orderbyid=asc&page=<?= $page ?>">Id
                                                (ASC)</a></li>
                                        <li><a class="dropdown-item" href="?orderbyid=desc&page=<?= $page ?>">Id
                                                (DESC)</a></li>
                                    </ul>
                                </div>
                            </th>
                            <th>
                                State Name
                                <div class="dropdown d-inline">
                                    <a class="btn dropdown-toggle" style="box-shadow:none;" href="#" role="button"
                                        id="dropdownMenuLink" data-bs-toggle="dropdown" aria-expanded="false">
                                        <i class="fa fa-sort"></i>
                                    </a>

                                    <ul class="dropdown-menu" aria-labelledby="dropdownMenuLink">
                                        <li><a class="dropdown-item" href="?orderbyname=asc&page=<?= $page ?>">Name
                                                (ASC)</a></li>
                                        <li><a class="dropdown-item" href="?orderbyname=desc&page=<?= $page ?>">Name
                                                (DESC)</a></li>
                                    </ul>
                                </div>
                            </th>
                            <th>Country Name</th>
                            <th>Edit State</s></th>
                            <th>Delete State</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        include("conn.php");

                        if (isset($_GET['status'])) {
                            $statusMessages = [
                                'success' => "Your record has been inserted successfully!",
                                'delete' => "Your record was deleted successfully!",
                                'update' => "Data updated successfully!"
                            ];
                            if (array_key_exists($_GET['status'], $statusMessages)) {
                                echo "<div class='alert alert-" . ($_GET['status'] === 'delete' ? 'danger' : ($_GET['status'] === 'update' ? 'primary' : 'success')) . " alert-dismissible fade show' role='alert'>" . $statusMessages[$_GET['status']] . "</div>";
                            }
                        }

                        $totalQuery = $con->query("SELECT COUNT(*) FROM states");
                        $total = $totalQuery->fetch_row()[0];

                        $search = isset($_GET['search']) ? $_GET['search'] : '';
                        $orderBy = 'id';
                        $orderDirection = 'ASC';

                        if (isset($_GET['orderbyid'])) {
                            $orderBy = 'id';
                            $orderDirection = ($_GET['orderbyid'] === 'asc') ? 'ASC' : 'DESC';
                        } elseif (isset($_GET['orderbyname'])) {
                            $orderBy = 'name';
                            $orderDirection = ($_GET['orderbyname'] === 'asc') ? 'ASC' : 'DESC';
                        }

                        $limit = 7;
                        $page = isset($_GET['page']) ? (int) $_GET['page'] : 1;
                        $page = max($page, 1);
                        $offset = ($page - 1) * $limit;
                        $total_pages = ceil($total / $limit);


                        if ($search) {
                            $stmt = $con->prepare("SELECT states.*, country.name AS country_name FROM states JOIN country ON states.country_id = country.id where s_name like ? ORDER BY $orderBy $orderDirection LIMIT ? OFFSET ? ");
                            $searchParam = "%$search%";
                            $stmt->bind_param('sii', $searchParam, $limit, $offset);
                            $stmt->execute();
                            $res = $stmt->get_result();

                        } else {


                            $stmt = $con->prepare("SELECT states.*, country.name AS country_name FROM states JOIN country ON states.country_id = country.id ORDER BY $orderBy $orderDirection LIMIT ? OFFSET ? ");
                            $stmt->bind_param('ii', $limit, $offset);
                            $stmt->execute();
                            $res = $stmt->get_result();
                        }
                        ?>
                        <tr>

                            <?php

                            if ($res->num_rows > 0) {
                                while ($row = $res->fetch_assoc()) {

                                    echo "<tr>";
                                    echo "<td>" . $row['id'] . "</td>";
                                    echo "<td>" . $row['s_name'] . "</td>";
                                    echo "<td>" . $row['country_name'] . "</td>";
                                    echo "<td><a href='stateAdd.php?id=" . ($row['id']) . "' class='btn btn-primary'>Edit</a></td>";
                                    ?>
                                    <td><a href='#' class='btn btn-danger' data-bs-toggle='modal' data-bs-target='#deleteModal'
                                            onclick='setDeleteId(<?php echo htmlspecialchars($row['id']); ?>)'>Delete</a></td>

                                    <div class="modal fade" id="deleteModal" tabindex="-1" aria-labelledby="deleteModalLabel"
                                        aria-hidden="true">
                                        <div class="modal-dialog">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title" id="deleteModalLabel">Confirm Deletion</h5>
                                                    <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                        aria-label="Close"></button>
                                                </div>
                                                <div class="modal-body">
                                                    Are you sure you want to delete this country?
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-secondary"
                                                        data-bs-dismiss="modal">Cancel</button>
                                                    <a id="confirmDelete" class="btn btn-danger">Delete</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <script>
                                        function setDeleteId(id) {
                                            const deleteLink = document.getElementById('confirmDelete');
                                            deleteLink.href = 'countryDelete.php?id=' + id;
                                        }
                                    </script>
                                    <?php

                                    echo "</tr>";
                                }

                            } ?>
                        </tr>
                        <?php

                        $stmt->close();
                        $con->close();
                        ?>
                    </tbody>
                </table>

                <!-- nav Pagination -->

                <nav aria-label="Page navigation">
                    <ul class="pagination justify-content-center mt-5">
                        <?php if ($page > 1): ?>
                            <li class="page-item">
                                <a class="page-link"
                                    href="?page=<?= $page - 1 ?>&orderbyid=<?= htmlspecialchars($_GET['orderbyid'] ?? '') ?>&orderbyname=<?= htmlspecialchars($_GET['orderbyname'] ?? '') ?>"
                                    aria-label="Previous">
                                    <span aria-hidden="true">&laquo;</span>
                                </a>
                            </li>
                        <?php endif; ?>

                        <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                            <li class="page-item <?= ($i == $page) ? 'active' : '' ?>">
                                <a class="page-link"
                                    href="?page=<?= $i ?>&orderbyid=<?= htmlspecialchars($_GET['orderbyid'] ?? '') ?>&orderbyname=<?= htmlspecialchars($_GET['orderbyname'] ?? '') ?>"><?= $i ?></a>
                            </li>
                        <?php endfor; ?>

                        <?php if ($page < $total_pages): ?>
                            <li class="page-item">
                                <a class="page-link"
                                    href="?page=<?= $page + 1 ?>&orderbyid=<?= htmlspecialchars($_GET['orderbyid'] ?? '') ?>&orderbyname=<?= htmlspecialchars($_GET['orderbyname'] ?? '') ?>"
                                    aria-label="Next">
                                    <span aria-hidden="true">&raquo;</span>
                                </a>
                            </li>
                        <?php endif; ?>
                    </ul>
                </nav>

            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p"
        crossorigin="anonymous"></script>
</body>

</html>