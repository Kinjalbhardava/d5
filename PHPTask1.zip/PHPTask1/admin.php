<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bootstrap 5 Vertical Nav Tabs</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel ="stylesheet" href="admin.css">
</head>

<body>

    <div class="container mt-5">
        <div class="row">
        
            <div class="col-3 bg-light">
                <h2 class="mb-4">Admin Panel</h2>
                <ul class="nav nav-pills flex-column" id="myTab" role="tablist">
                    <li class="nav-item" role="presentation">
                        <a class="nav-link active" id="home-tab" data-bs-toggle="pill" href="#home" role="tab"
                            aria-controls="home" aria-selected="true">Dashboard</a>
                    </li>
                    <li class="nav-item" role="presentation">
                        <a class="nav-link" id="profile-tab" data-bs-toggle="pill" href="#profile" role="tab"
                            aria-controls="profile" aria-selected="false">Country</a>
                    </li>
                    <li class="nav-item" role="presentation">
                        <a class="nav-link" id="state-tab" data-bs-toggle="pill" href="#state" role="tab"
                            aria-controls="state" aria-selected="false">State</a>
                    </li>
                    <li class="nav-item" role="presentation">
                        <a class="nav-link" id="city-tab" data-bs-toggle="pill" href="#city" role="tab"
                            aria-controls="city" aria-selected="false">City</a>
                    </li>
                </ul>
            </div>
            <div class="col-9">
                <div class="tab-content" id="myTabContent">
                    <div class="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="home-tab">
                        <h3>Dashboard</h3>
                        <div class="row mb-4">
                            <div class="col-md-4">
                                <div class="card">
                                    <div class="card-body">
                                        <h5 class="card-title">Total Countries</h5>
                                        <?php
                                        include("conn.php");
                                        $stmt = $con->prepare("SELECT COUNT(id) as country_count from country");
                                        $stmt->execute();
                                        $res = $stmt->get_result();
                                        if ($row = $res->fetch_assoc()) {
                                            echo "<p class='card-text'>" . $row['country_count'] . "</p>";
                                        }
                                        ?>
                                        <a href="country.php" class="btn btn-primary">View Countries</a>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="card">
                                    <div class="card-body">
                                        <h5 class="card-title">Total States</h5>
                                        <p class="card-text"></p>
                                        <a href="state.php" class="btn btn-primary">View States</a>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="card">
                                    <div class="card-body">
                                        <h5 class="card-title">Total Cities</h5>
                                        <p class="card-text"> </p>
                                        <a href="city.php" class="btn btn-primary">View Cities</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="tab-pane fade" id="profile" role="tabpanel" aria-labelledby="profile-tab">
                        <div class="row mb-4">
                            <div class="col">
                                <h3>Countries Listing</h3>
                            </div>
                            <div class="col text-end">
                                <a href="countryAdd.php" class="btn btn-primary mb-3">Add Country</a>
                            </div>
                        </div>

                        <form method="post" class="row mb-3">
                            <div class="col">
                                <input class="form-control" type="search" name="search" placeholder="Search"
                                    aria-label="Search">
                            </div>
                            <div class="col-auto">
                                <div class="btn-group btn-sm">
                                    <button type="button" class="btn btn-success dropdown-toggle"
                                        data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                        Sort
                                    </button>
                                    <ul class="dropdown-menu">
                                        <li><a class="dropdown-item" href="#profile?sort=id">Sort by ID</a></li>
                                        <li><a class="dropdown-item" href="#profile?sort=name">Sort by Name</a></li>
                                    </ul>
                                </div>
                            </div>
                        </form>

                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th>Country ID</th>
                                    <th>Country Name</th>
                                    <th>Edit Country</th>
                                    <th>Delete Country</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                include("conn.php");

                                $search = '';
                                if (isset($_POST['search']) && !empty($_POST['search'])) {
                                    $search = $_POST['search'];
                                }

                                $orderBy = 'id';
                                if (isset($_GET['sort'])) {
                                    if ($_GET['sort'] === 'name') {
                                        $orderBy = 'name';
                                    }
                                }

                                if ($search) {
                                    $stmt = $con->prepare("SELECT * FROM country WHERE name LIKE ? ORDER BY $orderBy ASC");
                                    $searchP = "%$search%";
                                    $stmt->bind_param('s', $searchP);
                                } else {
                                    $stmt = $con->prepare("SELECT * FROM country ORDER BY $orderBy ASC");
                                }

                                $stmt->execute();
                                $result = $stmt->get_result();

                                while ($row = $result->fetch_assoc()) {
                                    echo "<tr>";
                                    echo "<td>{$row['id']}</td>";
                                    echo "<td>{$row['name']}</td>";
                                    echo "<td><a href='countryAdd.php?id={$row['id']}' class='btn btn-primary'>Edit</a></td>";
                                    echo "<td><a href='countryDelete.php?id={$row['id']}' class='btn btn-danger'>Delete</a></td>";
                                    echo "</tr>";
                                }

                                $stmt->close();
                                $con->close();
                                ?>
                            </tbody>
                        </table>
                    </div>
                    <div class="tab-pane fade" id="state" role="tabpanel" href="state.php" aria-labelledby="state-tab">
                        <h4>State Tab</h4>
                        <p>This is the content for the State tab.</p>
                    </div>
                    <div class="tab-pane fade" id="city" role="tabpanel" aria-labelledby="city-tab">
                        <h4>City Tab</h4>
                        <p>This is the content for the City tab.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>
